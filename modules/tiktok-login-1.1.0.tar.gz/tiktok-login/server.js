/**
 * 模块：TikTok 账号登录（常驻会话版）
 *
 * 设计要点（对比第一版的问题）：
 *   ① **常驻会话**：浏览器只启动一次并保持，状态查询是即时的 —— 不再每次冷启动（原来要 10~40 秒）
 *   ② **非阻塞启动**：/start 立即返回，真正的加载在后台跑，前端轮询 /state 看进度
 *   ③ **细粒度状态**：启动中 → 加载页 → 等待扫码 → 已扫码待确认 → 需要验证码/密码 → 成功/失败
 *   ④ **扫码后可继续输入**：TikTok 扫码后常要求邮箱/短信验证码或密码，/submit 把输入填进去继续
 *
 * 全程无头（不弹窗）；登录态存 data/profiles-tiktok/<账号名>，支持多账号。
 */
const fs = require('fs');
const path = require('path');

const QR_URL = 'https://www.tiktok.com/login/qrcode';
const PWD_URL = 'https://www.tiktok.com/login/phone-or-email/email';

/** 单会话状态机 */
const S = {
  phase: 'idle', // idle | launching | loading | waiting-scan | scanned | need-input | logged-in | error
  message: '',
  qr: '',
  inputKind: '', // '' | 'code' | 'password' | 'account'
  account: '',
  at: 0,
};

let ctxRef = null;
let pageRef = null;
let profileName = 'default';
let ticker = null;

const set = (phase, message, extra) => {
  S.phase = phase;
  S.message = message || '';
  Object.assign(S, extra || {});
  S.at = Date.now();
};

/** 账号注册表：data/profiles-tiktok-accounts.json */
function accountsFile(ctx) {
  return path.join(ctx.baseDir, 'data', 'profiles-tiktok-accounts.json');
}
function readAccounts(ctx) {
  try {
    const j = JSON.parse(fs.readFileSync(accountsFile(ctx), 'utf8'));
    return Array.isArray(j.accounts) ? j.accounts : [];
  } catch (_) {
    return [];
  }
}
function addAccount(ctx, name) {
  if (!name || name === 'default') return;
  const list = readAccounts(ctx);
  if (!list.includes(name)) {
    list.push(name);
    fs.mkdirSync(path.dirname(accountsFile(ctx)), { recursive: true });
    fs.writeFileSync(accountsFile(ctx), JSON.stringify({ accounts: list }, null, 2));
  }
}

/** 保存的登录凭据（Round 6：存了密码的账号以后无头自动登录，失败才弹有头窗） */
function credsFile(ctx) {
  return path.join(ctx.baseDir, 'data', 'tiktok-creds.json');
}
function readCreds(ctx) {
  try {
    return JSON.parse(fs.readFileSync(credsFile(ctx), 'utf8'));
  } catch (_) {
    return {};
  }
}
function saveCreds(ctx, name, account, password) {
  if (!name || !account || !password) return;
  const all = readCreds(ctx);
  all[name] = { account, p: Buffer.from(String(password), 'utf8').toString('base64') };
  fs.mkdirSync(path.dirname(credsFile(ctx)), { recursive: true });
  fs.writeFileSync(credsFile(ctx), JSON.stringify(all, null, 2));
}
function getCreds(ctx, name) {
  const c = readCreds(ctx)[name];
  if (!c || !c.p) return null;
  return { account: c.account, password: Buffer.from(c.p, 'base64').toString('utf8') };
}

function profileDir(ctx, name) {
  const d = path.join(ctx.baseDir, 'data', 'profiles-tiktok', name || 'default');
  fs.mkdirSync(d, { recursive: true });
  return d;
}

/** 在页面与所有 frame 里找二维码 */
async function findQr(page) {
  const frames = [page.mainFrame()].concat(page.frames());
  for (const f of frames) {
    for (const sel of ['img[src^="data:image"]', 'canvas', 'img[class*="qr"]', '[class*="qrcode"] img', '[class*="qr-code"] img']) {
      try {
        const el = await f.$(sel);
        if (el) {
          const box = await el.boundingBox();
          if (box && box.width >= 120 && box.height >= 120) return el;
        }
      } catch (_) {}
    }
  }
  return null;
}

/** 读页面上的可见文案（判断走到哪一步） */
async function pageText(page) {
  try {
    return await page.evaluate(() => {
      const out = [];
      document.querySelectorAll('div,span,p,h1,h2,h3,button,label').forEach((e) => {
        if (e.children.length) return;
        const t = (e.textContent || '').trim();
        if (t && t.length <= 60) out.push(t);
      });
      return out.join(' | ');
    });
  } catch (_) {
    return '';
  }
}

const isLoggedInUrl = (u) => !!u && !/\/login/i.test(u) && !/^about:blank/.test(u);

/**
 * 更可靠的登录判定。
 * ⚠️ 用户实测：手机上确认后页面**会有一段时间仍停在 /login**（异步换 session），
 *    只靠 URL 会「确认了但界面没反应」。所以三条任一成立就算登录成功：
 *    ① URL 离开登录页 ② 拿到 sessionid/sessionid_ss cookie ③ 页面上出现已登录元素
 */
async function isLoggedIn(ctxRef, page) {
  try {
    const url = page.url();
    if (isLoggedInUrl(url)) return true;
  } catch (_) {}
  try {
    const cookies = await ctxRef.cookies('https://www.tiktok.com');
    if (cookies.some((c) => /^(sessionid|sessionid_ss|sid_tt)$/.test(c.name) && c.value)) return true;
  } catch (_) {}
  try {
    const hasAvatar = await page.evaluate(() => {
      return !!(
        document.querySelector('[data-e2e="profile-icon"], [data-e2e="nav-profile"], img[class*="avatar"], [class*="Avatar"]')
      );
    });
    if (hasAvatar) return true;
  } catch (_) {}
  return false;
}

/** 提交时暂存的凭据：等 ticker 确认登录成功后才真正落盘（失败的密码不存） */
let pendingCreds = null;

/** 后台心跳：每 1.5 秒刷新阶段（「不卡顿」的关键 —— 状态永远最新） */
function startTicker(ctx) {
  if (ticker) clearInterval(ticker);
  ticker = setInterval(async () => {
    if (!pageRef || !ctxRef) return;
    try {
      if (await isLoggedIn(ctxRef, pageRef)) {
        addAccount(ctx, profileName);
        if (pendingCreds) {
          saveCreds(ctx, profileName, pendingCreds.account, pendingCreds.password);
          ctx.log(`已保存「${profileName}」的登录凭据，以后自动无头登录`);
          pendingCreds = null;
        }
        set('logged-in', '登录成功');
        // 登录成功后自动关窗（用户要求：不要常驻浏览器窗口）
        setTimeout(() => closeSession().catch(() => {}), 1500);
        return;
      }
      const txt = await pageText(pageRef);
      if (/验证码|verification code|รหัสยืนยัน/i.test(txt) && !/扫码|scan/i.test(txt)) {
        const hasPwd = await pageRef.$('input[type=password]').catch(() => null);
        set('need-input', hasPwd ? '需要在页面上补充密码' : '需要输入验证码（查看手机短信或邮箱）', {
          inputKind: hasPwd ? 'password' : 'code',
        });
        return;
      }
      if (/扫描成功|已扫描|请在手机|confirm on your phone|ยืนยันบนมือถือ|scan success/i.test(txt)) {
        set('scanned', '已扫码 —— 请在手机上点确认');
        return;
      }
      if (S.phase !== 'waiting-scan' && S.phase !== 'scanned' && S.phase !== 'need-input') {
        const qr = await findQr(pageRef);
        if (qr) {
          try {
            const shot = await qr.screenshot();
            set('waiting-scan', '请用手机 TikTok 扫码', { qr: shot.toString('base64'), inputKind: '' });
          } catch (_) {
            set('waiting-scan', '请用手机 TikTok 扫码');
          }
        }
      }
    } catch (_) {}
  }, 1500);
}

async function ensureSession(ctx, name, forceVisible) {
  profileName = name || profileName || 'default';
  if (ctxRef) return ctxRef;
  const chromium = ctx.core.chromium;
  if (!chromium) throw new Error('核心没有提供 chromium');
  const exe = ctx.core.scraper.resolveChromePath();
  /**
   * 首次登录必须**有头**（TikTok 对无头会话不完成登录，用户实测扫码后无反应）；
   * 已经有登录态（profile 里存了 Cookies）时走无头，避免每次都弹窗。
   * forceVisible = 无头自动登录失败后的兜底：再弹有头窗让人处理（Round 6 用户要求）。
   */
  const hasSession = (() => {
    try { return fs.existsSync(path.join(profileDir(ctx, profileName), 'Default', 'Cookies')); } catch (_) { return false; }
  })();
  ctxRef = await chromium.launchPersistentContext(profileDir(ctx, profileName), {
    headless: forceVisible ? false : hasSession,
    viewport: { width: 1280, height: 900 },
    args: ['--no-first-run', '--disable-dev-shm-usage'],
    ...(exe ? { executablePath: exe } : {}),
  });
  ctxRef.on('close', () => {
    ctxRef = null;
    pageRef = null;
    if (ticker) clearInterval(ticker);
    ticker = null;
    if (S.phase !== 'logged-in') set('idle', '');
  });
  return ctxRef;
}

async function closeSession() {
  if (ticker) clearInterval(ticker);
  ticker = null;
  const c = ctxRef;
  ctxRef = null;
  pageRef = null;
  if (c) await c.close().catch(() => {});
}

module.exports = {
  register(app, ctx) {
    const { log } = ctx;

    /**
     * 无头密码自动登录（Round 6）：存过凭据的账号先走这条路，失败了才弹有头窗。
     * 用独立临时上下文，成功就把登录态写进同一 profile 后关掉。
     */
    async function tryHeadlessPasswordLogin(name, creds) {
      const chromium = ctx.core.chromium;
      if (!chromium) return false;
      const exe = ctx.core.scraper.resolveChromePath();
      let c = null;
      try {
        c = await chromium.launchPersistentContext(profileDir(ctx, name), {
          headless: true,
          viewport: { width: 1280, height: 900 },
          args: ['--no-first-run', '--disable-dev-shm-usage', '--window-position=-32000,-32000'],
          ...(exe ? { executablePath: exe } : {}),
        });
        const page = c.pages()[0] || (await c.newPage());
        await page.goto(PWD_URL, { waitUntil: 'domcontentloaded', timeout: 60000 });
        await page.waitForTimeout(3000);
        const frames = [page.mainFrame()].concat(page.frames());
        const fill = async (sel, val) => {
          for (const f of frames) {
            try {
              const el = await f.$(sel);
              if (el) { await el.fill(String(val)); return true; }
            } catch (_) {}
          }
          return false;
        };
        await fill('input[name=username], input[name=email]', creds.account);
        await fill('input[type=password]', creds.password);
        for (const f of frames) {
          try { await f.click('button[type=submit]', { timeout: 2000 }); break; } catch (_) {}
        }
        for (let i = 0; i < 25; i++) {
          await page.waitForTimeout(1000);
          try {
            const cookies = await c.cookies('https://www.tiktok.com');
            if (cookies.some((ck) => /^(sessionid|sessionid_ss|sid_tt)$/.test(ck.name) && ck.value)) return true;
          } catch (_) {}
          if (page.url() && !/\/login/i.test(page.url())) return true;
        }
        return false;
      } catch (_) {
        return false;
      } finally {
        if (c) await c.close().catch(() => {});
      }
    }

    /** 开始登录：**立即返回**，后台加载；前端轮询 /state 看进度 */
    app.post('/api/tiktok-login/start', async (req, res) => {
      const account = String((req.body && req.body.account) || '').trim();
      const mode = (req.body && req.body.mode) === 'password' ? 'password' : 'qr';
      res.json({ ok: true, started: true });
      (async () => {
        try {
          // ① 存了凭据 → 先无头自动登录（不弹窗）；失败再降级有头窗（用户要求）
          const creds = account ? getCreds(ctx, account) : null;
          if (creds) {
            set('launching', '正在用保存的凭据无头自动登录…', { qr: '', inputKind: '', account });
            const ok = await tryHeadlessPasswordLogin(account, creds);
            if (ok) {
              addAccount(ctx, account);
              set('logged-in', '已用保存的凭据自动登录（无头）');
              return;
            }
            set('launching', '无头自动登录失败，转为打开登录窗口…', { account });
          }
          set('launching', '正在打开登录窗口…', { qr: '', inputKind: '', account });
          await closeSession();
          const c = await ensureSession(ctx, account, !!creds);
          set('loading', '正在打开登录页…');
          const page = c.pages()[0] || (await c.newPage());
          pageRef = page;
          startTicker(ctx);
          await page.goto(mode === 'qr' ? QR_URL : PWD_URL, { waitUntil: 'domcontentloaded', timeout: 60000 });
          await page.waitForTimeout(2500);
          if (mode === 'qr') {
            const qr = await findQr(page);
            if (qr) {
              const shot = await qr.screenshot();
              set('waiting-scan', '登录窗口已打开 —— 请用手机扫码，或改用账密登录', { qr: shot.toString('base64'), inputKind: '' });
            } else {
              set('waiting-scan', '登录窗口已打开 —— 请在窗口中完成登录', { qr: '', inputKind: '' });
            }
          } else {
            set('need-input', '请输入账号与密码后提交', { inputKind: 'account' });
          }
        } catch (e) {
          set('error', '打开登录页失败：' + e.message);
        }
      })();
    });

    /** 状态查询（即时，不启动任何东西） */
    app.get('/api/tiktok-login/state', (req, res) => {
      res.json({
        phase: S.phase,
        message: S.message,
        qr: S.qr,
        inputKind: S.inputKind,
        account: S.account,
        loggedIn: S.phase === 'logged-in',
        since: S.at,
        open: !!ctxRef,
      });
    });

    /** 扫码后补充输入（验证码 / 密码 / 账号密码） */
    app.post('/api/tiktok-login/submit', async (req, res) => {
      const b = req.body || {};
      try {
        if (!pageRef) return res.status(400).json({ error: '会话已关闭，请重新开始' });
        const page = pageRef;
        const frames = [page.mainFrame()].concat(page.frames());
        const fill = async (sel, val) => {
          for (const f of frames) {
            try {
              const el = await f.$(sel);
              if (el) {
                await el.fill(String(val));
                return true;
              }
            } catch (_) {}
          }
          return false;
        };
        let acted = false;
        if (b.account) acted = (await fill('input[name=username], input[name=email], input[type=text]', b.account)) || acted;
        if (b.password) acted = (await fill('input[type=password]', b.password)) || acted;
        if (b.code) acted = (await fill('input[inputmode=numeric], input[name=code], input[type=text]', b.code)) || acted;
        if (!acted) return res.status(400).json({ error: '页面上找不到可填写的输入框（结构可能变了）' });
        // 账密提交 → 暂存，等登录真的成功（ticker 判定）后才落盘保存
        if (b.account && b.password) pendingCreds = { account: b.account, password: b.password };
        for (const f of frames) {
          try {
            await f.click('button[type=submit]', { timeout: 2000 });
            break;
          } catch (_) {}
        }
        set('loading', '已提交，正在验证…');
        res.json({ ok: true });
      } catch (e) {
        res.status(500).json({ error: e.message });
      }
    });

    /** 关闭会话 / 退出 */
    app.post('/api/tiktok-login/close', async (req, res) => {
      await closeSession();
      set('idle', '');
      res.json({ ok: true });
    });

    /**
     * 已登录账号列表。
     * ⚠️ 绝不能直接列 data/profiles-tiktok 下的目录 —— 那是 Chromium 的 user-data-dir，
     *    里面全是 ActorSafetyLists / CaptchaProviders 这类内部目录（踩过这个坑）。
     *    只读我们自己维护的注册表。
     */
    app.get('/api/tiktok-login/accounts', (req, res) => {
      res.json({ accounts: readAccounts(ctx), current: profileName });
    });

    /* ==================== 创作中心数据同步（Round 6） ====================
       抓取完成后核心会调用 collect()，把创作中心指标（平均观看时长/完播率/流量来源）
       按 vid 合并进视频列表；重合字段由核心剔除（以 TikTok 抓取为准）。
       ⚠️ 创作中心的接口是 TikTok 内部接口，没有公开文档 —— 这里是 best-effort 探测：
       端点变了/账号没权限就安静跳过（返回 {}），绝不影响主抓取。 */
    const CREATOR_ENDPOINTS = [
      'https://www.tiktok.com/api/creator_center/video/list/',
      'https://www.tiktok.com/api/creator/video/list/',
    ];

    function firstProfileWithSession() {
      for (const name of readAccounts(ctx)) {
        try {
          if (fs.existsSync(path.join(profileDir(ctx, name), 'Default', 'Cookies'))) return name;
        } catch (_) {}
      }
      return null;
    }

    /** 从任意形态的响应里挖「视频列表」数组 */
    function digVideoList(j) {
      if (!j || typeof j !== 'object') return null;
      const cands = [j.data && j.data.video_list, j.data && j.data.list, j.video_list, j.list, j.data && j.data.videos];
      for (const c of cands) if (Array.isArray(c) && c.length) return c;
      return null;
    }

    /** 把一条创作中心视频记录规范化成 { vid: 字段 }（只保留平台独有字段） */
    function normCreatorItem(it) {
      const vid = String(it.video_id || it.item_id || it.id || '');
      if (!/^\d{6,}$/.test(vid)) return null;
      const out = {};
      const num = (v) => {
        const n = Number(v);
        return Number.isFinite(n) ? n : undefined;
      };
      // 平均观看时长（秒）/ 完播率 / 流量来源 —— 创作中心独有
      const awt = num(it.avg_watch_time ?? it.avgWatchTime ?? it.avg_play_duration);
      if (awt !== undefined) out.avgWatchTime = Math.round(awt * 10) / 10;
      const fin = num(it.finish_rate ?? it.completion_rate ?? it.play_finish_rate);
      if (fin !== undefined) out.finishRate = fin <= 1 ? Math.round(fin * 1000) / 10 : Math.round(fin * 10) / 10;
      const src = it.traffic_source || it.trafficSource;
      if (src && typeof src === 'object') out.trafficSource = JSON.stringify(src);
      return Object.keys(out).length ? { vid, fields: out } : null;
    }

    if (typeof ctx.registerSync === 'function') {
      ctx.registerSync({
        platform: 'creator',
        collect: async () => {
          const name = firstProfileWithSession();
          if (!name) return {}; // 没登录 = 没有创作中心权限，跳过
          const chromium = ctx.core.chromium;
          if (!chromium) return {};
          const exe = ctx.core.scraper.resolveChromePath();
          let c = null;
          try {
            c = await chromium.launchPersistentContext(profileDir(ctx, name), {
              headless: true,
              viewport: { width: 1280, height: 900 },
              args: ['--no-first-run', '--disable-dev-shm-usage', '--window-position=-32000,-32000'],
              ...(exe ? { executablePath: exe } : {}),
            });
            const map = {};
            for (const base of CREATOR_ENDPOINTS) {
              try {
                const resp = await c.request.get(`${base}?aid=1988&count=100&cursor=0`, {
                  headers: { Referer: 'https://www.tiktok.com/creator-center' },
                  timeout: 15000,
                });
                if (!resp.ok()) continue;
                const j = await resp.json().catch(() => null);
                const list = digVideoList(j);
                if (!list) continue;
                for (const it of list) {
                  const n = normCreatorItem(it);
                  if (n) map[n.vid] = n.fields;
                }
                if (Object.keys(map).length) break; // 有一个端点通了就够了
              } catch (_) {}
            }
            return map;
          } catch (_) {
            return {};
          } finally {
            if (c) await c.close().catch(() => {});
          }
        },
      });
    }

    log('创作中心数据导入模块已挂载：/api/tiktok-login/*（常驻会话 + 数据同步）');
  },
};
