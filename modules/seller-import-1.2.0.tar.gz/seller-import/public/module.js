/* 卖家中心登录 —— 只有两个页面：登录 / 多账号管理
 *
 * 交互原则（用户明确要求）：
 *   · 登录 = 打开真实浏览器窗口登录，不在应用里塞表单
 *   · 首次（没有登录态）才弹窗；登录成功自动关窗；之后该账号一律无头运行
 *   · 每个账号一个独立浏览器档案，互不串号
 */
(function () {
  // 用数字实体，避免写入时被当成 HTML 吞掉
  const ESC = { '&': '&#38;', '<': '&#60;', '>': '&#62;', '"': '&#34;', "'": '&#39;' };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ESC[c]);

  function mount(root, ctx) {
    const t = ctx.t;
    const api = (u, o) => fetch(u, o).then((x) => x.json());
    const post = (u, b) =>
      api(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b || {}) });

    // 从「设置 → 登录」小弹窗进来时只显示登录页（不塞页签、不塞账号表格）
    const only = !!ctx.loginOnly;
    root.innerHTML = `
      <div class="si-tabs"${only ? ' style="display:none"' : ''}>
        <button class="on" data-p="login">${esc(t('siTabLogin'))}</button>
        <button data-p="accounts">${esc(t('siTabAccounts'))}</button>
      </div>
      <div id="siPageLogin"></div>
      <div id="siPageAccounts" style="display:none"></div>`;

    const $ = (s) => root.querySelector(s);
    let accounts = [];
    let active = '';

    /* ---------------- 通用 ---------------- */
    const cur = () => accounts.find((a) => a.id === active) || accounts[0] || null;

    async function load() {
      const d = await api('/api/seller-import/accounts').catch(() => ({ accounts: [], active: '' }));
      accounts = d.accounts || [];
      active = d.active || (accounts[0] && accounts[0].id) || '';
    }

    root.querySelectorAll('.si-tabs button').forEach((b) =>
      b.addEventListener('click', () => {
        root.querySelectorAll('.si-tabs button').forEach((x) => x.classList.toggle('on', x === b));
        const p = b.dataset.p;
        $('#siPageLogin').style.display = p === 'login' ? '' : 'none';
        $('#siPageAccounts').style.display = p === 'accounts' ? '' : 'none';
      })
    );

    /* ---------------- 页 1：登录 ---------------- */
    function renderLogin() {
      const a = cur();
      const box = $('#siPageLogin');
      if (!a) {
        box.innerHTML =
          `<div class="si-hint">${esc(t('siNoAccount'))}</div>` +
          (only
            ? ''
            : `<div class="si-row"><button id="siGoAccounts" class="btn-like primary">${esc(t('siTabAccounts'))}</button></div>`);
        const g = $('#siGoAccounts');
        if (g) g.addEventListener('click', () => root.querySelector('.si-tabs button[data-p="accounts"]').click());
        return;
      }

      box.innerHTML = `
        <div class="si-row">
          <span class="si-hint">${esc(t('siCurrentAccount'))}</span>
          <select id="siAccSel" class="si-select"></select>
        </div>
        <div class="si-row">
          <button id="siLoginBtn" class="btn-like primary">${esc(t('siOpenWindowLogin'))}</button>
          <button id="siOpenBtn" class="btn-like">${esc(t('siOpenSellerWindow'))}</button>
          <button id="siCheckBtn" class="btn-like">${esc(t('siCheckStatus'))}</button>
          <button id="siLogoutBtn" class="btn-like danger">${esc(t('siLogout'))}</button>
        </div>
        <div id="siState" class="si-status">${esc(t('siSession'))}：${
          a.hasSession ? '<b class="ok">' + esc(t('siSessionYes')) + '</b>' : '<b class="err">' + esc(t('siSessionNo')) + '</b>'
        }${a.lastLoginAt ? ' · ' + esc(t('siLastLogin')) + '：' + esc(a.lastLoginAt.slice(0, 16).replace('T', ' ')) : ''}</div>
        <div class="si-hint">${esc(t('siOpenWindowHint'))}</div>
        <div class="si-hint">${esc(t('siExportHint'))}</div>`;

      $('#siAccSel').innerHTML = accounts
        .map((x) => `<option value="${esc(x.id)}"${x.id === active ? ' selected' : ''}>${esc(x.label || x.account)}${x.hasSession ? ' ✓' : ''}</option>`)
        .join('');

      const st = (m, c) => {
        const e = $('#siState');
        if (e) { e.textContent = m || ''; e.className = 'si-status' + (c ? ' ' + c : ''); }
      };

      $('#siAccSel').addEventListener('change', async () => {
        await post('/api/seller-import/accounts/' + encodeURIComponent($('#siAccSel').value) + '/active');
        await load();
        renderLogin();
      });

      $('#siLoginBtn').addEventListener('click', async () => {
        st(t('siOpeningWindow'), '');
        $('#siLoginBtn').disabled = true;
        try {
          const r = await post('/api/seller-import/accounts/' + encodeURIComponent(cur().id) + '/login', {});
          if (r.error) throw new Error(r.error);
          st((r.note || '') + (r.visible ? ' ' + t('siWindowOpened') : ''), r.visible ? 'wait' : 'ok');
          setTimeout(async () => { await load(); renderLogin(); }, 1500);
        } catch (e) {
          st(e.message, 'err');
        } finally {
          $('#siLoginBtn').disabled = false;
        }
      });

      $('#siOpenBtn').addEventListener('click', async () => {
        st(t('siOpeningWindow'), '');
        try {
          const r = await post('/api/seller-import/open-browser', { id: cur().id, visible: true });
          if (r.error) throw new Error(r.error);
          st(r.note || t('siWindowOpened'), 'ok');
        } catch (e) { st(e.message, 'err'); }
      });

      $('#siCheckBtn').addEventListener('click', async () => {
        st(t('siChecking'), '');
        try {
          const r = await api('/api/seller-import/status?id=' + encodeURIComponent(cur().id));
          st(r.loggedIn ? t('siStatusLoggedIn') : t('siStatusOffline'), r.loggedIn ? 'ok' : 'err');
        } catch (e) { st(e.message, 'err'); }
        await load();
        renderLogin();
      });

      $('#siLogoutBtn').addEventListener('click', async () => {
        await post('/api/seller-import/accounts/' + encodeURIComponent(cur().id) + '/logout').catch(() => {});
        await load();
        renderLogin();
        renderAccounts();
      });
    }

    /* ---------------- 页 2：多账号管理 ---------------- */
    function renderAccounts() {
      const box = $('#siPageAccounts');
      box.innerHTML = `
        <div class="tbl-wrap"><table class="ec-table">
          <thead><tr>
            <th>${esc(t('siLabel'))}</th>
            <th>${esc(t('siAcc'))}</th>
            <th>${esc(t('siSession'))}</th>
            <th>${esc(t('siLastLogin'))}</th>
            <th>${esc(t('siAction'))}</th>
          </tr></thead>
          <tbody id="siAccBody"></tbody>
        </table></div>
        <div class="si-row" style="margin-top:10px">
          <input id="siNewLabel" class="si-select" placeholder="${esc(t('siLabel'))}" style="min-width:130px">
          <input id="siNewAcc" class="si-select" placeholder="${esc(t('siAcc'))}" autocomplete="off" style="min-width:170px">
          <input id="siNewPwd" class="si-select" type="password" placeholder="${esc(t('siPwd'))}" autocomplete="new-password" style="min-width:150px">
          <button id="siAddBtn" class="btn-like primary">${esc(t('siAddAccount'))}</button>
        </div>
        <div class="si-hint">${esc(t('siPwdOptional'))}</div>`;

      $('#siAccBody').innerHTML = accounts.length
        ? accounts
            .map(
              (a) => `<tr>
            <td>${esc(a.label || '')}${a.id === active ? ' <b class="ok">·${esc(t('siCurrent'))}</b>' : ''}</td>
            <td>${esc(a.account)}</td>
            <td>${a.hasSession ? '<b class="ok">' + esc(t('siSessionYes')) + '</b>' : '<span class="err">' + esc(t('siSessionNo')) + '</span>'}</td>
            <td>${esc(a.lastLoginAt ? a.lastLoginAt.slice(0, 16).replace('T', ' ') : '-')}</td>
            <td>
              <button class="btn-like sm" data-act="login" data-id="${esc(a.id)}">${esc(t('siLogin'))}</button>
              <button class="btn-like sm" data-act="switch" data-id="${esc(a.id)}">${esc(t('siSwitch'))}</button>
              <button class="btn-like sm" data-act="logout" data-id="${esc(a.id)}">${esc(t('siLogout'))}</button>
              <button class="btn-like sm danger" data-act="del" data-id="${esc(a.id)}">${esc(t('siDelete'))}</button>
            </td>
          </tr>`
            )
            .join('')
        : `<tr><td colspan="5" class="si-hint">${esc(t('siNoAccountYet'))}</td></tr>`;

      box.querySelectorAll('button[data-act]').forEach((b) =>
        b.addEventListener('click', async () => {
          const id = b.dataset.id;
          const one = accounts.find((x) => x.id === id);
          if (b.dataset.act === 'switch') {
            await post('/api/seller-import/accounts/' + encodeURIComponent(id) + '/active');
          } else if (b.dataset.act === 'login') {
            b.disabled = true;
            await post('/api/seller-import/accounts/' + encodeURIComponent(id) + '/login', {}).catch(() => {});
          } else if (b.dataset.act === 'logout') {
            await post('/api/seller-import/accounts/' + encodeURIComponent(id) + '/logout').catch(() => {});
          } else if (b.dataset.act === 'del') {
            if (!confirm(t('siDeleteConfirm', { account: (one && one.account) || id }))) return;
            await fetch('/api/seller-import/accounts/' + encodeURIComponent(id), { method: 'DELETE' }).catch(() => {});
          }
          await load();
          renderAccounts();
          renderLogin();
        })
      );

      $('#siAddBtn').addEventListener('click', async () => {
        const account = $('#siNewAcc').value.trim();
        if (!account) return;
        const r = await post('/api/seller-import/accounts', {
          account,
          label: $('#siNewLabel').value.trim() || account,
          password: $('#siNewPwd').value,
        }).catch((e) => ({ error: e.message }));
        if (r.error) return alert(r.error);
        $('#siNewLabel').value = '';
        $('#siNewAcc').value = '';
        $('#siNewPwd').value = '';
        await load();
        renderAccounts();
        renderLogin();
      });
    }

    (async () => {
      await load();
      renderLogin();
      renderAccounts();
    })();
  }

  window.TTModule.register({ id: 'seller-import', title: '卖家数据导入', icon: '⇪', mount });
})();
